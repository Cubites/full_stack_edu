import React from 'react'
import styled from 'styled-components';

const Mainbox = styled.div`
  width: 100%;
  height: 500px;
  background: #E66B27;
`

const Main = () => {
  return (
    <Mainbox>

    </Mainbox>
  )
}

export default Main