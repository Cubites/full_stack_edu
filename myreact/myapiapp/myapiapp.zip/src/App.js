import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Main from './components/Main';
import Test from './Test';

const App = () => {
  return (
    <div>
      <Main />
    </div>
  )
}

export default App